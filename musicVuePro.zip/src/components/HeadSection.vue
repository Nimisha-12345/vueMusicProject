<template>
    <div class="part">
        <h1>Mtv Music</h1>
        <!-- <Music /> -->
    </div>

</template>

<script>
// import Music from '../components/Music'
export default {
    name:"HeaderSection",
    // components:{
    //     Music,
    // }
}
</script>

<style >
/* .part h1{
    text-align: center;
} */

</style>